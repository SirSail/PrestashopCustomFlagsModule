# FlagsModule - Niestandardowe flagi produktów

## Opis
Moduł FlagsModule umożliwia dodawanie niestandardowych flag  w PrestaShop. Umożliwia przypisywanie flag do wszystkich produktów lub tylko do produktów w wybranej kategorii.

## Instalacja
1. **Pobierz moduł:**
   - Pobierz plik `flagsmodule.zip` i rozpakuj go.

2. **Instalacja w PrestaShop:**
   - Przejdź do panelu administracyjnego PrestaShop.
   - Wybierz "Moduły" -> "Menedżer modułów".
   - Kliknij "Załaduj moduł".
   - Prześlij plik `flagsmodule.zip` i zainstaluj moduł.

3. **Konfiguracja:**
   - Po instalacji przejdź do zakładki "Konfiguruj" w sekcji "Moduły -> Administracja -> Niestandardowe flagi produktów".
   - Możesz dodawać nowe flagi oraz przypisywać istniejące flagi do wszystkich produktów lub do produktów w określonej kategorii.

## Wykorzystane hooki
- **displayAdminProductsExtra:** Hook, który w przystępny sposób wyświetla flagi przypisane do produktów w formularzu edycji produktu.
- **actionProductUpdate:** Przechwytuje zdarzenie aktualizacji produktu, aby zaktualizować przypisane flagi.

## Implementacja funkcjonalności
1. **Dodawanie flag:** Użytkownik może dodać nowe flagi za pomocą formularza w panelu administracyjnym.
2. **Przypisywanie flag:** Użytkownik ma możliwość przypisania flag do wszystkich produktów lub tylko do produktów w danej kategorii.
3. **Baza danych:** Moduł tworzy dwie tabele:
   - `product_flags`: Przechowuje informacje o flagach
   - `product_flag_assignment`: Łączy produkty z flagami.
## Znany błąd

### Błędne przypisywanie flag do produktów

W trakcie korzystania z modułu może wystąpić znany błąd związany z **błędnym przypisywaniem flag** do wszystkich produktów oraz do produktów w określonej kategorii. Problem ten prowadzi do wstawienia wartości `flag_id = 0` do bazy danych w tabeli `product_flag_assignment`, co skutkuje błędami w operacjach na bazie danych.

## Wsparcie
Dla wsparcia technicznego skontaktuj się z autorem modułu: SirSail.
