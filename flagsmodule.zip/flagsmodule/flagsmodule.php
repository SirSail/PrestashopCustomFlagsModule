<?php 

if (!defined('_PS_VERSION_')) {
    exit;
}

class FlagsModule extends Module
{
    public function __construct()
    {
        $this->name = 'flagsmodule';
        $this->tab = 'administration';
        $this->version = '0.0.1';
        $this->author = 'SirSail';
        $this->need_instance = 0;
        $this->bootstrap = true;
        parent::__construct();
        
        $this->displayName = $this->l('Niestandardowe flagi produktów');
        $this->description = $this->l('Moduł do dodawania niestandardowych flag produktów.');
        $this->ps_versions_compliancy = ['min' => '1.6.0.0', 'max' => _PS_VERSION_];
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');

        if (!Configuration::get('FLAGSMODULE_NAME')) {
            $this->warning = $this->l('No name provided for FLAGSMODULE_NAME configuration.');
        }
    }

    public function getContent()
    {
        $output = '';

        // Obsługuje dodanie nowej flagi
        if (Tools::isSubmit('submitNewFlag')) {
            $flagName = Tools::getValue('flag_name');

    

            if (empty($flagName)) {
                $this->errors[] = $this->l('Nazwa flagi nie może być pusta.');
            } else {
                $data = [
                    'flag_name' => pSQL($flagName)
                ];
                if (!Db::getInstance()->insert('product_flags', $data)) {
                    $this->errors[] = $this->l('Nie udało się dodać nowej flagi.');
                } else {
                    $this->confirmations[] = $this->l('Flaga została dodana.');
                }
            }
        }
        // Obsługuje przypisywanie flag do wszystkich produktów
        if (Tools::isSubmit('submitAssignFlagsToAll')) {
            $flag_ids = Tools::getValue('flags', []); 
            
            if (!empty($flag_ids)) {
                // Pobranie wszystkich produktów w sklepie - możliwe że powoduje błąd 
                $products = Db::getInstance()->executeS('SELECT id_product FROM ' . _DB_PREFIX_ . 'product');
                
                foreach ($products as $product) {
                    Db::getInstance()->delete(_DB_PREFIX_ . 'product_flag_assignment', 'id_product = ' . (int)$product['id_product']);
       
                    foreach ($flag_ids as $id_flag) {
                        $exists = Db::getInstance()->getValue('
                            SELECT COUNT(*) 
                            FROM ' . _DB_PREFIX_ . 'product_flag_assignment 
                            WHERE id_product = ' . (int)$product['id_product'] . ' AND id_flag = ' . (int)$id_flag
                        );
                        
                        if ($exists == 0) {
                            Db::getInstance()->insert('product_flag_assignment', [
                                'id_product' => (int)$product['id_product'],
                                'id_flag' => (int)$id_flag,
                            ]);
                        }
                    }
                }
                $this->confirmations[] = $this->l('Flagi zostały przypisane do wszystkich produktów.');
            } else {
                
                $this->errors[] = $this->l('Wybierz co najmniej jedną flagę.');
            }
        }
        // Obsługuje przypisywanie flag do produktów w wybranej kategorii
        if (Tools::isSubmit('submitAssignFlagsToCategory')) {
            $flag_ids = Tools::getValue('flags', []); 
            $category_id = Tools::getValue('category_id');
        
            if (!empty($flag_ids) && !empty($category_id)) {

                $products = Db::getInstance()->executeS('
                    SELECT p.id_product 
                    FROM ' . _DB_PREFIX_ . 'product p 
                    JOIN ' . _DB_PREFIX_ . 'category_product cp ON p.id_product = cp.id_product
                    WHERE cp.id_category = ' . (int)$category_id);
        
        
                foreach ($products as $product) {
                    $deletedRows = Db::getInstance()->delete(_DB_PREFIX_ . 'product_flag_assignment', 'id_product = ' . (int)$product['id_product']);
                   
        
                    
                    foreach ($flag_ids as $id_flag) {
                    
                        $exists = Db::getInstance()->getValue('
                            SELECT COUNT(*) 
                            FROM ' . _DB_PREFIX_ . 'product_flag_assignment 
                            WHERE id_product = ' . (int)$product['id_product'] . ' AND id_flag = ' . (int)$id_flag);
        
                        if ($exists == 0) {
                            $success = Db::getInstance()->insert('product_flag_assignment', [
                                'id_product' => (int)$product['id_product'],
                                'id_flag' => (int)$id_flag,
                            ]);
                            if (!$success) {
                                $sqlError = Db::getInstance()->getMsgError();
                                var_dump('Insert nie powiódł się dla produktu: ' . $product['id_product'] . ' i flagi: ' . $id_flag);
                                var_dump('Błąd SQL: ' . $sqlError);
                            }
                        } else {
                            var_dump('Flaga dla produktu ' . $product['id_product'] . ' już istnieje.');
                        }
                    }
                }
                $this->confirmations[] = $this->l('Flagi zostały przypisane do produktów w kategorii.');
            } else {
                $this->errors[] = $this->l('Wybierz kategorię i co najmniej jedną flagę.');
            }
        }
        
        return $output . $this->renderForm();
    }
    
    public function renderForm()
    {
        $flags = Db::getInstance()->executeS('SELECT * FROM ' . _DB_PREFIX_ . 'product_flags');
        $categories = Category::getCategories($this->context->language->id, true, false);
        $id_product = (int)Tools::getValue('id_product');
        
        if ($id_product) {
            $assigned_flags = Db::getInstance()->executeS('
                SELECT f.flag_name
                FROM ' . _DB_PREFIX_ . 'product_flag_assignment pfa
                JOIN ' . _DB_PREFIX_ . 'product_flags f ON f.id_flag = pfa.id_flag
                WHERE pfa.id_product = ' . (int)$id_product
            );
            $this->context->smarty->assign('assigned_flags', $assigned_flags);
        }

        $this->fields_form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Dodaj nową flagę'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'text',
                        'label' => $this->l('Nazwa flagi'),
                        'name' => 'flag_name',
                        'required' => true,
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Dodaj'),
                    'class' => 'btn btn-default pull-right',
                    'name' => 'submitNewFlag',
                ],
            ],
        ];

        $flags_form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Przypisz flagi do wszystkich produktów'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'checkbox',
                        'label' => $this->l('Wybierz flagi'),
                        'name' => 'flags[]',
                        'values' => [
                            'query' => $flags, 
                            'id' => 'id_flag', 
                            'name' => 'flag_name', 
                        ],
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Przypisz do wszystkich produktów'),
                    'class' => 'btn btn-default pull-right',
                    'name' => 'submitAssignFlagsToAll',
                ],
            ],
        ];

        $category_flags_form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Przypisz flagi do produktów w wybranej kategorii'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'select',
                        'label' => $this->l('Wybierz kategorię'),
                        'name' => 'category_id',
                        'options' => [
                            'query' => $categories,
                            'id' => 'id_category',
                            'name' => 'name',
                        ],
                        'required' => true,
                    ],
                    [
                        'type' => 'checkbox',
                        'label' => $this->l('Wybierz flagi'),
                        'name' => 'flags[]', 
                        'values' => [
                            'query' => $flags,
                            'id' => 'id_flag',
                            'name' => 'flag_name',
                        ],
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Przypisz do produktów w kategorii'),
                    'class' => 'btn btn-default pull-right',
                    'name' => 'submitAssignFlagsToCategory',
                ],
            ],
        ];

        return $this->renderFormHelper($this->fields_form)
            . $this->renderFormHelper($flags_form)
            . $this->renderFormHelper($category_flags_form);
    }

    private function renderFormHelper($fields_form)
    {
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->submit_action = 'submit' . $this->name;
        $helper->tpl_vars = [
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        ];

        return $helper->generateForm([$fields_form]);
    }


    public function install()
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return parent::install()
            && $this->registerHook('displayAdminProductsExtra')
            && $this->registerHook('actionProductUpdate')
            && Configuration::updateValue('FLAGSMODULE_NAME', 'flagsmodule')
            && $this->installDB()
            && $this->installTab(); // Rejestrujemy zakładkę
    }

    public function installDB()
    {
        return Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'product_flags` (
            `id_flag` INT(11) NOT NULL AUTO_INCREMENT,
            `flag_name` VARCHAR(255) NOT NULL,
            PRIMARY KEY (`id_flag`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;'
        ) && Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'product_flag_assignment` (
            `id_product` INT(11) NOT NULL,
            `id_flag` INT(11) NOT NULL,
            PRIMARY KEY (`id_product`, `id_flag`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;'
        );
    }
    public function hookDisplayAdminProductsExtra($params)
    {
        $id_product = (int)$params['id_product'];

        $flags = Db::getInstance()->executeS('SELECT * FROM ' . _DB_PREFIX_ . 'product_flags');
        $assigned_flags = Db::getInstance()->executeS('
            SELECT id_flag FROM ' . _DB_PREFIX_ . 'product_flag_assignment WHERE id_product = ' . (int)$id_product
        );
        $this->context->smarty->assign('assigned_flags', array_column($assigned_flags, 'id_flag'));

        
        $this->context->smarty->assign('flags', $flags);

        return $this->fetch('module:flagsmodule/views/templates/admin/product_flags.tpl');
    }

    public function hookActionProductUpdate($params)
    {
        $id_product = (int)$params['id_product'];
        $flags = Tools::getValue('flags', []); 
    
        $deleteResult = Db::getInstance()->delete(_DB_PREFIX_ . 'product_flag_assignment', 'id_product = ' . $id_product);
    
   
        foreach ($flags as $id_flag) {
            
                $insertResult = Db::getInstance()->insert('product_flag_assignment', [
                    'id_product' => $id_product,
                    'id_flag' => (int)$id_flag,
                ]);
               
             
                
            }
        }

    
    public function uninstall()
    {
        return parent::uninstall()
            && $this->uninstallDB()
            && Configuration::deleteByName('FLAGSMODULE_NAME');
    }

    public function uninstallDB()
    {
        $sql = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'product_flags`, `'._DB_PREFIX_.'product_flag_assignment`';
        return Db::getInstance()->execute($sql);
    }

    public function installTab()
    {
       
        $tab = new Tab();
        $tab->class_name = 'AdminFlagsModule'; 
        $tab->id_parent = (int)Tab::getIdFromClassName('AdminParentModules');
        $tab->module = $this->name;
        $tab->name = array_fill_keys(Language::getIDs(false), 'Niestandardowe flagi'); 
        return $tab->add();
    }
}

