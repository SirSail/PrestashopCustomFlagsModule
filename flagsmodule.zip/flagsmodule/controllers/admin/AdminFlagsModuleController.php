<?php
class AdminFlagsModuleController extends ModuleAdminController
{
    public function __construct()
    {

        parent::__construct();
    }
//     public function getContent()
//     {
//         $this->postProcess(); 
//         return $this->renderForm(); 
//     }
//     public function postProcess()
// {
//     if (Tools::isSubmit('submitNewFlag')) {
//         $flagName = Tools::getValue('flag_name');

//         if (empty($flagName)) {
//             $this->errors[] = $this->l('Nazwa flagi nie może być pusta.');
//         } else {
//             $sql = 'INSERT INTO ' . _DB_PREFIX_ . 'product_flags (flag_name) VALUES ("' . pSQL($flagName) . '")';
//             if (!Db::getInstance()->execute($sql)) {
//                 $this->errors[] = $this->l('Nie udało się dodać nowej flagi.');
//             } else {
//                 $this->confirmations[] = $this->l('Flaga została dodana.');
//             }
//         }
//     }

//     // Obsługa przypisywania flag do wszystkich produktów
//     if (Tools::isSubmit('submitAssignFlagsToAll')) {
//         $flag_ids = Tools::getValue('flags', []);
        
//         if (!empty($flag_ids)) {
//             // Pobierz wszystkie produkty
//             $products = Db::getInstance()->executeS('SELECT id_product FROM ' . _DB_PREFIX_ . 'product');
            
//             foreach ($products as $product) {
//                 // Usuwamy stare przypisania flag dla tego produktu
//                 Db::getInstance()->delete(_DB_PREFIX_ . 'product_flag_assignment', 'id_product = ' . (int)$product['id_product']);
                
//                 // Przypisz nowe flagi do każdego produktu
//                 foreach ($flag_ids as $id_flag) {
//                     Db::getInstance()->insert('product_flag_assignment', [
//                         'id_product' => (int)$product['id_product'],
//                         'id_flag' => (int)$id_flag,
//                     ]);
//                 }
//             }

//             $this->confirmations[] = $this->l('Flagi zostały przypisane do wszystkich produktów.');
//         } else {
//             $this->errors[] = $this->l('Wybierz co najmniej jedną flagę.');
//         }
//     }
// }
// public function renderForm()
// {
//     $flags = Db::getInstance()->executeS('SELECT * FROM ' . _DB_PREFIX_ . 'product_flags');

//     $this->fields_form = [
//         'form' => [
//             'legend' => [
//                 'title' => $this->l('Dodaj nową flagę'),
//                 'icon' => 'icon-cogs',
//             ],
//             'input' => [
//                 [
//                     'type' => 'text',
//                     'label' => $this->l('Nazwa flagi'),
//                     'name' => 'flag_name',
//                     'required' => true,
//                 ],
//             ],
//             'submit' => [
//                 'title' => $this->l('Dodaj'),
//                 'class' => 'btn btn-default pull-right',
//                 'name' => 'submitNewFlag',
//             ],
//         ],
//     ];

//     $flags_form = [
//         'form' => [
//             'legend' => [
//                 'title' => $this->l('Przypisz flagi do wszystkich produktów'),
//                 'icon' => 'icon-cogs',
//             ],
//             'input' => [
//                 [
//                     'type' => 'checkbox',
//                     'label' => $this->l('Wybierz flagi'),
//                     'name' => 'flags',
//                     'values' => [
//                         'query' => $flags,
//                         'id' => 'id_flag',
//                         'name' => 'flag_name',
//                     ],
//                 ],
//             ],
//             'submit' => [
//                 'title' => $this->l('Przypisz do wszystkich produktów'),
//                 'class' => 'btn btn-default pull-right',
//                 'name' => 'submitAssignFlagsToAll',
//             ],
//         ],
//     ];

//     return parent::renderForm() . $this->renderFormHelper($flags_form);
// }

// 
}
